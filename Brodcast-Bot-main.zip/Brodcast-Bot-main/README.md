
# Brodcast Bot 📣

## Get Started ( For Repil it ) 
* Go To `Secerts`
* Type This
```
Key : token
value : <your-token>
```

* and 
```
Key : ch
value : <btodcast-channel>
```
* Go To Shell And Type This 
```
npm i discord.js@12.5.3 express
``` 
* Watting to Install All Packages And Click To Run Button

### Support 🔰
Discord Acount : `!ZombieX#0001`
[Server Discord](https://discord.gg/crJx77aEsq) - [YouTube Channel](https://youtube.com/channel/UC0A5FZItuziL5iWIinQeKcQ)

### Made By `ZombieX` ✨
* All Copyrights Go To ZombieX 
